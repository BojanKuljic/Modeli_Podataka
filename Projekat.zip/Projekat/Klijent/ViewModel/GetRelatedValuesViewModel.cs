﻿using FTN.Common;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Klijent.ViewModel
{
    public class GetRelatedValuesViewModel : BindableBase
    {
        public MyICommand ShowButton { get; set; }
        public MyICommand ClearButton { get; set; }
        public MyICommand LeftToRightButton { get; set; }
        public MyICommand RightToLeftButton { get; set; }

        private DMSType selectedDmsType = 0;
        private long selectedGlobalId = 0;
        private ModelCode selectedLeft = 0, selectedRight = 0;
        private ModelCode reference = 0;

        private ObservableCollection<DMSType> dmsTypes = new ObservableCollection<DMSType>();
        private ObservableCollection<long> globalIds = new ObservableCollection<long>();
        private ObservableCollection<ModelCode> allProperties = new ObservableCollection<ModelCode>();
        private ObservableCollection<ModelCode> selectedProperties = new ObservableCollection<ModelCode>();
        private ObservableCollection<ModelCode> references = new ObservableCollection<ModelCode>();

        private string gdaOutput = "";

        public GetRelatedValuesViewModel()
        {
            ClearAction();
            ShowButton = new MyICommand(ShowAction);
            ClearButton = new MyICommand(ClearAction);
            LeftToRightButton = new MyICommand(LeftToRightAction);
            RightToLeftButton = new MyICommand(RightToLefction);
        }

        void LeftToRightAction()
        {
            try
            {
                if (SelectedLeft != 0)
                {
                    SelectedProperties.Add(SelectedLeft);
                    AllProperties.Remove(SelectedLeft);
                    SelectedLeft = SelectedRight = 0;
                }
            }
            catch
            {
                SelectedLeft = SelectedRight = 0;
            }
        }

        void RightToLefction()
        {
            try
            {
                if (SelectedRight != 0)
                {
                    SelectedProperties.Remove(SelectedRight);
                    AllProperties.Add(SelectedRight);
                    SelectedLeft = SelectedRight = 0;
                }
            }
            catch
            {
                SelectedLeft = SelectedRight = 0;
            }
        }

        void ShowAction()
        {
            if (SelectedGlobalId != 0 && SelectedDmsType != 0 && SelectedProperties.Count > 0 && Reference != 0)
            {
                string retVal = GetRelatedValues(SelectedGlobalId, SelectedProperties.ToList(), new Association(Reference), Reference);

                if (retVal.Equals(""))
                    GDAOutput = "Nema entita u sistemu po zadatom kriterijumu.";
                else
                    GDAOutput = retVal;
            }
        }

        void ClearAction()
        {
            List<DMSType> temp = new ModelResourcesDesc().AllDMSTypes.ToList();
            temp.Remove(DMSType.MASK_TYPE);
            DmsTypes = new ObservableCollection<DMSType>(temp);
            SelectedDmsType = DmsTypes.First();
            GDAOutput = "";
        }

        public DMSType SelectedDmsType
        {
            get => selectedDmsType;
            set
            {
                if (selectedDmsType != value)
                {
                    selectedDmsType = value;
                    OnPropertyChanged("SelectedDmsType");
                    PopulateGlobalIdsAndReferences();
                }
            }
        }

        public long SelectedGlobalId
        {
            get => selectedGlobalId;
            set
            {
                if (selectedGlobalId != value)
                {
                    selectedGlobalId = value;
                    OnPropertyChanged("SelectedGlobalId");
                }
            }
        }

        public ModelCode Reference
        {
            get => reference;
            set
            {
                if (reference != value)
                {
                    reference = value;
                    OnPropertyChanged("Reference");

                    SelectedLeft = SelectedRight = 0;
                    SelectedProperties.Clear();
                    AllProperties.Clear();

                    if (reference == 0)
                        return;

                    string requested_class = Reference.ToString().Split('_')[1];

                    if (requested_class[requested_class.Length - 1].Equals('S'))
                        requested_class = requested_class.Remove(requested_class.Length - 1, 1);

                    ModelCode model_code = new ModelResourcesDesc().GetModelCodeFromModelCodeName(requested_class);

                    AllProperties = new ObservableCollection<ModelCode>(new ModelResourcesDesc().GetAllPropertyIds(model_code));
                }
            }
        }

        public ModelCode SelectedLeft
        {
            get => selectedLeft;
            set
            {
                if (selectedLeft != value)
                {
                    selectedLeft = value;
                    OnPropertyChanged("SelectedLeft");
                }
            }
        }

        public ModelCode SelectedRight
        {
            get => selectedRight;
            set
            {
                if (selectedRight != value)
                {
                    selectedRight = value;
                    OnPropertyChanged("SelectedRight");
                }
            }
        }

        public ObservableCollection<DMSType> DmsTypes
        {
            get => dmsTypes;
            set
            {
                if (dmsTypes != value)
                {
                    dmsTypes = value;
                    OnPropertyChanged("DmsTypes");
                }
            }
        }

        public ObservableCollection<long> GlobalIds
        {
            get => globalIds;
            private set
            {
                if (globalIds != value)
                {
                    globalIds = value;
                    OnPropertyChanged("GlobalIds");
                }
            }
        }

        public ObservableCollection<ModelCode> SelectedProperties
        {
            get => selectedProperties;
            set
            {
                if (selectedProperties != value)
                {
                    selectedProperties = value;
                    OnPropertyChanged("SelectedProperties");
                }
            }
        }

        public ObservableCollection<ModelCode> References
        {
            get => references;
            set
            {
                if (references != value)
                {
                    references = value;
                    OnPropertyChanged("References");
                }
            }
        }

        public ObservableCollection<ModelCode> AllProperties
        {
            get => allProperties;
            set
            {
                if (allProperties != value)
                {
                    allProperties = value;
                    OnPropertyChanged("AllProperties");
                }
            }
        }

        public string GDAOutput
        {
            get => gdaOutput;
            set
            {
                if (gdaOutput != value)
                {
                    gdaOutput = value;
                    OnPropertyChanged("GDAOutput");
                }
            }
        }

        #region Helper methods
        void PopulateGlobalIdsAndReferences()
        {
            GlobalIds.Clear();
            SelectedProperties.Clear();
            AllProperties.Clear();
            References.Clear();

            SelectedLeft = SelectedRight = 0;
            Reference = 0;
            SelectedGlobalId = 0;
            GDAOutput = "";

            long reference_mask = 0x0000000000000009, references_mask = 0x0000000000000019;
            List<ModelCode> allProps = new ModelResourcesDesc().GetAllPropertyIds(SelectedDmsType);
            List<ModelCode> filtered = allProps.FindAll(x => ((((long)x & reference_mask) == reference_mask) || (((long)x & references_mask) == references_mask)));
            References = new ObservableCollection<ModelCode>(filtered);

            GlobalIds = GIDs();
        }

        ObservableCollection<long> GIDs()
        {
            int iteratorId = 0;
            List<long> ids = new List<long>();

            try
            {
                int numberOfResources = 2;
                int resourcesLeft = 0;

                List<ModelCode> properties = new ModelResourcesDesc().GetAllPropertyIds(SelectedDmsType);

                iteratorId = GDAProxy.Instance.GetProxy().GetExtentValues(new ModelResourcesDesc().GetModelCodeFromType(SelectedDmsType), properties);
                resourcesLeft = GDAProxy.Instance.GetProxy().IteratorResourcesLeft(iteratorId);

                while (resourcesLeft > 0)
                {
                    List<ResourceDescription> rds = GDAProxy.Instance.GetProxy().IteratorNext(numberOfResources, iteratorId);

                    for (int i = 0; i < rds.Count; i++)
                    {
                        ids.Add(rds[i].Id);
                    }

                    resourcesLeft = GDAProxy.Instance.GetProxy().IteratorResourcesLeft(iteratorId);
                }

                GDAProxy.Instance.GetProxy().IteratorClose(iteratorId);
            }
            catch (Exception e)
            {
                CommonTrace.WriteTrace(true, string.Format("Getting extent values method failed for {0}. {1}", SelectedDmsType, e.Message));
            }

            ObservableCollection<long> gids = new ObservableCollection<long>(ids);

            return gids;
        }

        public string GetRelatedValues(long globalId, List<ModelCode> props, Association association, ModelCode requestedEntityType)
        {
            int iteratorId = 0;
            string retVal = "";
            List<long> ids = new List<long>();

            try
            {
                int numberOfResources = 2;
                int resourcesLeft = 0;

                iteratorId = GDAProxy.Instance.GetProxy().GetRelatedValues(globalId, props, association);
                resourcesLeft = GDAProxy.Instance.GetProxy().IteratorResourcesLeft(iteratorId);

                while (resourcesLeft > 0)
                {
                    List<ResourceDescription> rds = GDAProxy.Instance.GetProxy().IteratorNext(numberOfResources, iteratorId);

                    for (int i = 0; i < rds.Count; i++)
                    {
                        ids.Add(rds[i].Id);
                    }

                    resourcesLeft = GDAProxy.Instance.GetProxy().IteratorResourcesLeft(iteratorId);
                }

                GDAProxy.Instance.GetProxy().IteratorClose(iteratorId);

                foreach (long gid in ids)
                {

                    retVal += (GetValuesViewModel.GetValues(gid, props)) + "\n";
                }
            }
            catch (Exception e)
            {
                retVal = e.Message;
            }

            return retVal;
        }
        #endregion
    }
}
