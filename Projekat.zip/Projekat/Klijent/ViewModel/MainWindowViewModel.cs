﻿using FTN.ServiceContracts;
using System;
using System.ComponentModel;
using System.Runtime.CompilerServices;
using System.ServiceModel;
using System.Windows.Input;

namespace Klijent.ViewModel
{
    public class MainWindowViewModel : BindableBase
    {
        public GetValuesViewModel GetValuesViewModel;
        public GetRelatedValuesViewModel GetExtentValuesViewModel;
        public GetExtentValuesViewModel GetRelatedValuesViewModel;

        public MainWindowViewModel()
        {
            GetValuesViewModel = new GetValuesViewModel();
            GetExtentValuesViewModel = new GetRelatedValuesViewModel();
            GetRelatedValuesViewModel = new GetExtentValuesViewModel();
        }

    }

    #region Bindable Base Class
    public class BindableBase : INotifyPropertyChanged
    {
        protected virtual void SetProperty<T>(ref T member, T val,
           [CallerMemberName] string propertyName = null)
        {
            if (object.Equals(member, val)) return;

            member = val;
            PropertyChanged(this, new PropertyChangedEventArgs(propertyName));
        }

        protected virtual void OnPropertyChanged(string propertyName)
        {
            PropertyChanged(this, new PropertyChangedEventArgs(propertyName));
        }

        public event PropertyChangedEventHandler PropertyChanged = delegate { };
    }
    #endregion

    #region ICommand Class
    public class MyICommand : ICommand
    {
        Action _TargetExecuteMethod;
        Func<bool> _TargetCanExecuteMethod;

        public MyICommand(Action executeMethod)
        {
            _TargetExecuteMethod = executeMethod;
        }

        public MyICommand(Action executeMethod, Func<bool> canExecuteMethod)
        {
            _TargetExecuteMethod = executeMethod;
            _TargetCanExecuteMethod = canExecuteMethod;
        }

        public void RaiseCanExecuteChanged()
        {
            CanExecuteChanged(this, EventArgs.Empty);
        }

        bool ICommand.CanExecute(object parameter)
        {

            if (_TargetCanExecuteMethod != null)
            {
                return _TargetCanExecuteMethod();
            }

            if (_TargetExecuteMethod != null)
            {
                return true;
            }

            return false;
        }

        public event EventHandler CanExecuteChanged = delegate { };

        void ICommand.Execute(object parameter)
        {
            if (_TargetExecuteMethod != null)
            {
                _TargetExecuteMethod();
            }
        }
    }

    public class MyICommand<T> : ICommand
    {

        Action<T> _TargetExecuteMethod;
        Func<T, bool> _TargetCanExecuteMethod;

        public MyICommand(Action<T> executeMethod)
        {
            _TargetExecuteMethod = executeMethod;
        }

        public MyICommand(Action<T> executeMethod, Func<T, bool> canExecuteMethod)
        {
            _TargetExecuteMethod = executeMethod;
            _TargetCanExecuteMethod = canExecuteMethod;
        }

        public void RaiseCanExecuteChanged()
        {
            CanExecuteChanged(this, EventArgs.Empty);
        }

        #region ICommand Members

        bool ICommand.CanExecute(object parameter)
        {

            if (_TargetCanExecuteMethod != null)
            {
                T tparm = (T)parameter;
                return _TargetCanExecuteMethod(tparm);
            }

            if (_TargetExecuteMethod != null)
            {
                return true;
            }

            return false;
        }

        public event EventHandler CanExecuteChanged = delegate { };

        void ICommand.Execute(object parameter)
        {
            if (_TargetExecuteMethod != null)
            {
                _TargetExecuteMethod((T)parameter);
            }
        }

        #endregion
    }
    #endregion

    #region GDA WCF Proxy
    public class GDAProxy
    {
        private static readonly Lazy<GDAProxy> instance =
            new Lazy<GDAProxy>(() => new GDAProxy());

        private readonly ChannelFactory<INetworkModelGDAContract> channelFactory;

        public static GDAProxy Instance => instance.Value;

        private GDAProxy()
        {
            try
            {
                var binding = new NetTcpBinding
                {
                    Security = { Mode = SecurityMode.None }
                };
                var endpointAddress = new EndpointAddress("net.tcp://localhost:10000/NetworkModelService/GDA/");

                channelFactory = new ChannelFactory<INetworkModelGDAContract>(binding, endpointAddress);
            }
            catch { }
        }

        public INetworkModelGDAContract GetProxy()
        {
            if (channelFactory == null)
                return new ChannelFactory<INetworkModelGDAContract>().CreateChannel();
            else
                return channelFactory.CreateChannel();
        }

        public void Dispose()
        {
            if (channelFactory != null)
            {
                channelFactory.Close();
            }
        }
    }
    #endregion
}
