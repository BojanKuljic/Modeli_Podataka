﻿using FTN.Common;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;

namespace Klijent.ViewModel
{
    public class GetExtentValuesViewModel : BindableBase
    {
        public MyICommand ShowButton { get; set; }
        public MyICommand ClearButton { get; set; }
        public MyICommand LeftToRightButton { get; set; }
        public MyICommand RightToLeftButton { get; set; }

        private DMSType selectedDmsType = 0;
        private ModelCode selectedLeft = 0, selectedRight = 0;

        private ObservableCollection<DMSType> dmsTypes = new ObservableCollection<DMSType>();
        private ObservableCollection<ModelCode> allProperties = new ObservableCollection<ModelCode>();
        private ObservableCollection<ModelCode> selectedProperties = new ObservableCollection<ModelCode>();

        private string gdaOutput = "";

        public GetExtentValuesViewModel()
        {
            ClearAction();
            ShowButton = new MyICommand(ShowAction);
            ClearButton = new MyICommand(ClearAction);
            LeftToRightButton = new MyICommand(LeftToRightAction);
            RightToLeftButton = new MyICommand(RightToLefction);
        }

        void LeftToRightAction()
        {
            try
            {
                if (SelectedLeft != 0)
                {
                    SelectedProperties.Add(SelectedLeft);
                    AllProperties.Remove(SelectedLeft);
                    SelectedLeft = SelectedRight = 0;
                }
            }
            catch
            {
                SelectedLeft = SelectedRight = 0;
            }
        }

        void RightToLefction()
        {
            try
            {
                if (SelectedRight != 0)
                {
                    SelectedProperties.Remove(SelectedRight);
                    AllProperties.Add(SelectedRight);
                    SelectedLeft = SelectedRight = 0;
                }
            }
            catch
            {
                SelectedLeft = SelectedRight = 0;
            }
        }

        void ShowAction()
        {
            if (SelectedDmsType != 0 && SelectedProperties.Count > 0)
            {
                string retVal = GetExtentValues(SelectedDmsType, SelectedProperties.ToList());

                if (retVal.Equals(""))
                    GDAOutput = "Nema entita u sistemu po zadatom kriterijumu.";
                else
                    GDAOutput = retVal;
            }
        }

        void ClearAction()
        {
            List<DMSType> temp = new ModelResourcesDesc().AllDMSTypes.ToList();
            temp.Remove(DMSType.MASK_TYPE);
            DmsTypes = new ObservableCollection<DMSType>(temp);
            SelectedDmsType = DmsTypes.First();
            GDAOutput = "";
        }

        public DMSType SelectedDmsType
        {
            get => selectedDmsType;
            set
            {
                if (selectedDmsType != value)
                {
                    selectedDmsType = value;
                    OnPropertyChanged("SelectedDmsType");
                    PopulateGlobalIdsAndProperties();
                }
            }
        }

        public ModelCode SelectedLeft
        {
            get => selectedLeft;
            set
            {
                if (selectedLeft != value)
                {
                    selectedLeft = value;
                    OnPropertyChanged("SelectedLeft");
                }
            }
        }

        public ModelCode SelectedRight
        {
            get => selectedRight;
            set
            {
                if (selectedRight != value)
                {
                    selectedRight = value;
                    OnPropertyChanged("SelectedRight");
                }
            }
        }

        public ObservableCollection<DMSType> DmsTypes
        {
            get => dmsTypes;
            set
            {
                if (dmsTypes != value)
                {
                    dmsTypes = value;
                    OnPropertyChanged("DmsTypes");
                }
            }
        }

        public ObservableCollection<ModelCode> SelectedProperties
        {
            get => selectedProperties;
            set
            {
                if (selectedProperties != value)
                {
                    selectedProperties = value;
                    OnPropertyChanged("SelectedProperties");
                }
            }
        }

        public ObservableCollection<ModelCode> AllProperties
        {
            get => allProperties;
            set
            {
                if (allProperties != value)
                {
                    allProperties = value;
                    OnPropertyChanged("AllProperties");
                }
            }
        }

        public string GDAOutput
        {
            get => gdaOutput;
            set
            {
                if (gdaOutput != value)
                {
                    gdaOutput = value;
                    OnPropertyChanged("GDAOutput");
                }
            }
        }

        #region Helper methods
        void PopulateGlobalIdsAndProperties()
        {
            SelectedProperties.Clear();
            AllProperties.Clear();

            SelectedLeft = SelectedRight = 0;
            GDAOutput = "";

            AllProperties = new ObservableCollection<ModelCode>(new ModelResourcesDesc().GetAllPropertyIds(SelectedDmsType));
        }


        string GetExtentValues(DMSType type, List<ModelCode> props)
        {
            int iteratorId = 0;
            List<long> ids = new List<long>();
            string retVal = "";
            ModelCode modelCode = new ModelResourcesDesc().GetModelCodeFromType(type);

            try
            {
                int numberOfResources = 2;
                int resourcesLeft = 0;
                iteratorId = GDAProxy.Instance.GetProxy().GetExtentValues(modelCode, props);
                resourcesLeft = GDAProxy.Instance.GetProxy().IteratorResourcesLeft(iteratorId);

                while (resourcesLeft > 0)
                {
                    List<ResourceDescription> rds = GDAProxy.Instance.GetProxy().IteratorNext(numberOfResources, iteratorId);

                    for (int i = 0; i < rds.Count; i++)
                    {
                        ids.Add(rds[i].Id);
                    }

                    resourcesLeft = GDAProxy.Instance.GetProxy().IteratorResourcesLeft(iteratorId);
                }

                GDAProxy.Instance.GetProxy().IteratorClose(iteratorId);

                foreach (long gid in ids)
                {
                    retVal += GetValuesViewModel.GetValues(gid, props) + "\n";
                }
            }
            catch (Exception e)
            {
                retVal = e.Message;
            }

            return retVal;
        }
        #endregion
    }
}
