﻿using FTN.Common;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Klijent.ViewModel
{
    public class GetValuesViewModel : BindableBase
    {
        public MyICommand ShowButton { get; set; }
        public MyICommand ClearButton { get; set; }
        public MyICommand LeftToRightButton { get; set; }
        public MyICommand RightToLeftButton { get; set; }

        private DMSType selectedDmsType = 0;
        private long selectedGlobalId = 0;
        private ModelCode selectedLeft = 0, selectedRight = 0;

        private ObservableCollection<DMSType> dmsTypes = new ObservableCollection<DMSType>();
        private ObservableCollection<long> globalIds = new ObservableCollection<long>();
        private ObservableCollection<ModelCode> allProperties = new ObservableCollection<ModelCode>();
        private ObservableCollection<ModelCode> selectedProperties = new ObservableCollection<ModelCode>();

        private string gdaOutput = "";

        public GetValuesViewModel()
        {
            ClearAction();
            ShowButton = new MyICommand(ShowAction);
            ClearButton = new MyICommand(ClearAction);
            LeftToRightButton = new MyICommand(LeftToRightAction);
            RightToLeftButton = new MyICommand(RightToLefction);
        }

        void LeftToRightAction()
        {
            try
            {
                if (SelectedLeft != 0)
                {
                    SelectedProperties.Add(SelectedLeft);
                    AllProperties.Remove(SelectedLeft);
                    SelectedLeft = SelectedRight = 0;
                }
            }
            catch
            {
                SelectedLeft = SelectedRight = 0;
            }
        }

        void RightToLefction()
        {
            try
            {
                if (SelectedRight != 0)
                {
                    SelectedProperties.Remove(SelectedRight);
                    AllProperties.Add(SelectedRight);
                    SelectedLeft = SelectedRight = 0;
                }
            }
            catch
            {
                SelectedLeft = SelectedRight = 0;
            }
        }

        void ShowAction()
        {
            if(SelectedGlobalId != 0 && SelectedDmsType != 0 && SelectedProperties.Count > 0)
            {
                string retVal = GetValues(SelectedGlobalId, SelectedProperties.ToList());

                if (retVal.Equals(""))
                    GDAOutput = "Nema entita u sistemu po zadatom kriterijumu.";
                else
                    GDAOutput = retVal;
            }
        }

        void ClearAction()
        {
            List<DMSType> temp = new ModelResourcesDesc().AllDMSTypes.ToList();
            temp.Remove(DMSType.MASK_TYPE);
            DmsTypes = new ObservableCollection<DMSType>(temp);
            SelectedDmsType = DmsTypes.First();
            GDAOutput = "";
        }

        public DMSType SelectedDmsType
        {
            get => selectedDmsType;
            set
            {
                if(selectedDmsType != value)
                {
                    selectedDmsType = value;
                    OnPropertyChanged("SelectedDmsType");
                    PopulateGlobalIdsAndProperties();
                }
            }
        }

        public long SelectedGlobalId
        {
            get => selectedGlobalId;
            set
            {
                if(selectedGlobalId != value)
                {
                    selectedGlobalId = value;
                    OnPropertyChanged("SelectedGlobalId");
                }
            }
        }

        public ModelCode SelectedLeft
        {
            get => selectedLeft;
            set
            {
                if (selectedLeft != value)
                {
                    selectedLeft = value;
                    OnPropertyChanged("SelectedLeft");
                }
            }
        }

        public ModelCode SelectedRight
        {
            get => selectedRight;
            set
            {
                if (selectedRight != value)
                {
                    selectedRight = value;
                    OnPropertyChanged("SelectedRight");
                }
            }
        }

        public ObservableCollection<DMSType> DmsTypes
        {
            get => dmsTypes;
            set
            {
                if (dmsTypes != value)
                {
                    dmsTypes = value;
                    OnPropertyChanged("DmsTypes");
                }
            }
        }

        public ObservableCollection<long> GlobalIds
        {
            get => globalIds;
            private set
            {
                if (globalIds != value)
                {
                    globalIds = value;
                    OnPropertyChanged("GlobalIds");
                }
            }
        }

        public ObservableCollection<ModelCode> SelectedProperties
        {
            get => selectedProperties;
            set
            {
                if (selectedProperties != value)
                {
                    selectedProperties = value;
                    OnPropertyChanged("SelectedProperties");
                }
            }
        }

        public ObservableCollection<ModelCode> AllProperties
        {
            get => allProperties;
            set
            {
                if (allProperties != value)
                {
                    allProperties = value;
                    OnPropertyChanged("AllProperties");
                }
            }
        }

        public string GDAOutput
        {
            get => gdaOutput;
            set
            {
                if(gdaOutput != value)
                {
                    gdaOutput = value;
                    OnPropertyChanged("GDAOutput");
                }
            }
        }

        #region Helper methods
        void PopulateGlobalIdsAndProperties()
        {
            GlobalIds.Clear();
            SelectedProperties.Clear();
            AllProperties.Clear();

            SelectedLeft = SelectedRight = 0;
            SelectedGlobalId = 0;
            GDAOutput = "";

            AllProperties = new ObservableCollection<ModelCode>(new ModelResourcesDesc().GetAllPropertyIds(SelectedDmsType));
            GlobalIds = GIDs();
        }

        ObservableCollection<long> GIDs()
        {
            int iteratorId = 0;
            List<long> ids = new List<long>();

            try
            {
                int numberOfResources = 2;
                int resourcesLeft = 0;

                List<ModelCode> properties = new ModelResourcesDesc().GetAllPropertyIds(SelectedDmsType);

                iteratorId = GDAProxy.Instance.GetProxy().GetExtentValues(new ModelResourcesDesc().GetModelCodeFromType(SelectedDmsType), properties);
                resourcesLeft = GDAProxy.Instance.GetProxy().IteratorResourcesLeft(iteratorId);

                while (resourcesLeft > 0)
                {
                    List<ResourceDescription> rds = GDAProxy.Instance.GetProxy().IteratorNext(numberOfResources, iteratorId);

                    for (int i = 0; i < rds.Count; i++)
                    {
                        ids.Add(rds[i].Id);
                    }

                    resourcesLeft = GDAProxy.Instance.GetProxy().IteratorResourcesLeft(iteratorId);
                }

                GDAProxy.Instance.GetProxy().IteratorClose(iteratorId);
            }
            catch (Exception e)
            {
                CommonTrace.WriteTrace(true, string.Format("Getting extent values method failed for {0}. {1}", SelectedDmsType, e.Message));
            }

            ObservableCollection<long> gids = new ObservableCollection<long>(ids);

            return gids;
        }
        //metodi se prosledjuje GID i lista MC/ova koji predstavljaju identifikatore propertija vezanih za entitet
        public static string GetValues(long globalId, List<ModelCode> props)
        {
            string retVal = "";

            try
            {
                //rezultat  je RD koji sadrzi prosledjeni identifikator  i listu zahtevanih propertija
                ResourceDescription rd = GDAProxy.Instance.GetProxy().GetValues(globalId, props);
                List<Property> Properties = rd.Properties;

                foreach (Property prop in Properties)
                {
                    if (prop.Type == PropertyType.Float)
                    {
                        retVal += $"{prop.Id}: {prop.AsFloat()}\n";
                    }
                    else if (prop.Type == PropertyType.Byte || prop.Type == PropertyType.Int32 ||
                             prop.Type == PropertyType.Int64 || prop.Type == PropertyType.TimeSpan)
                    {
                        retVal += $"{prop.Id}: 0x{prop.AsLong().ToString("X")}\n";
                    }
                    else if (prop.Type == PropertyType.Bool)
                    {
                        retVal += $"{prop.Id}: {(prop.AsBool() ? "✓" : "X")}\n";
                    }
                    else if (prop.Type == PropertyType.DateTime)
                    {
                        retVal += $"{prop.Id}: {prop.AsDateTime()}\n";
                    }
                    else if (prop.Type == PropertyType.Enum)
                    {
                        try
                        {
                            retVal += $"{prop.Id}: {new EnumDescs().GetStringFromEnum(prop.Id, prop.AsEnum())}\n";
                        }
                        catch (Exception)
                        {
                            retVal += $"{prop.Id}: {prop.AsEnum()}\n";
                        }
                    }
                    else if (prop.Type == PropertyType.Reference)
                    {
                        retVal += $"{prop.Id}: 0x{prop.AsReference().ToString("X")}\n";
                    }
                    else if (prop.Type == PropertyType.String)
                    {
                        retVal += $"{prop.Id}: {prop.AsString()}\n";
                    }
                    else if (prop.Type == PropertyType.Int64Vector || prop.Type == PropertyType.ReferenceVector)
                    {
                        if (prop.AsLongs().Count > 0)
                        {
                            retVal += $"{prop.Id}:";
                            foreach (var value in prop.AsLongs())
                                retVal += $" 0x{value.ToString("X")} ";
                            retVal += "\n";
                        }
                        else
                            retVal += $"{prop.Id}: empty {prop.Type.ToString().ToLower()} vector\n";
                    }
                    else if (prop.Type == PropertyType.TimeSpanVector)
                    {
                        if (prop.AsTimeSpans().Count > 0)
                        {
                            retVal += $"{prop.Id}:\n";
                            foreach (var value in prop.AsTimeSpans())
                                retVal += $" 0x{value.ToString("X")}\n";
                        }
                        else
                            retVal += $"{prop.Id}: empty {prop.Type.ToString().ToLower()} vector\n";
                    }
                    else if (prop.Type == PropertyType.Int32Vector)
                    {
                        if (prop.AsInts().Count > 0)
                        {
                            retVal += $"{prop.Id}:\n";
                            foreach (var value in prop.AsInts())
                                retVal += $"- {value}\n";
                        }
                        else
                            retVal += $"{prop.Id}: empty {prop.Type.ToString().ToLower()} vector\n";
                    }
                    else if (prop.Type == PropertyType.DateTimeVector)
                    {
                        if (prop.AsDateTimes().Count > 0)
                        {
                            retVal += $"{prop.Id}:\n";
                            foreach (var value in prop.AsDateTimes())
                                retVal += $"- {value}\n";
                        }
                        else
                            retVal += $"{prop.Id}: empty {prop.Type.ToString().ToLower()} vector\n";
                    }
                    else if (prop.Type == PropertyType.BoolVector)
                    {
                        if (prop.AsBools().Count > 0)
                        {
                            retVal += $"{prop.Id}:\n";
                            foreach (var value in prop.AsBools())
                                retVal += $"- {value}\n";
                        }
                        else
                            retVal += $"{prop.Id}: empty {prop.Type.ToString().ToLower()} vector\n";
                    }
                    else if (prop.Type == PropertyType.FloatVector)
                    {
                        if (prop.AsFloats().Count > 0)
                        {
                            retVal += $"{prop.Id}:\n";
                            foreach (var value in prop.AsFloats())
                                retVal += $"- {value}\n";
                        }
                        else
                            retVal += $"{prop.Id}: empty {prop.Type.ToString().ToLower()} vector\n";
                    }
                    else if (prop.Type == PropertyType.StringVector)
                    {
                        if (prop.AsStrings().Count > 0)
                        {
                            retVal += $"{prop.Id}:\n";
                            foreach (var value in prop.AsStrings())
                                retVal += $"- {value}\n";
                        }
                        else
                            retVal += $"{prop.Id}: empty {prop.Type.ToString().ToLower()} vector\n";
                    }
                    else if (prop.Type == PropertyType.EnumVector)
                    {
                        if (prop.AsEnums().Count > 0)
                        {
                            retVal += $"{prop.Id}:\n";
                            foreach (var value in prop.AsEnums())
                                retVal += $"- {value}\n";
                        }
                        else
                            retVal += $"{prop.Id}: empty {prop.Type.ToString().ToLower()} vector\n";
                    }
                    else
                    {
                        retVal += $"Unknown property type for {prop.Id}\n";
                    }
                }
            }
            catch (Exception e)
            {
                retVal += e.Message;
            }

            return retVal;
        }
        #endregion
    }
}
