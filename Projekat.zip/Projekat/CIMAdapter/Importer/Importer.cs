﻿using System;
using System.Collections.Generic;
using CIM.Model;
using FTN.Common;
using FTN.ESI.SIMES.CIM.CIMAdapter.Manager;

namespace FTN.ESI.SIMES.CIM.CIMAdapter.Importer
{
	/// <summary>
	/// PowerTransformerImporter
	/// </summary>
	public class Importer
	{
		/// <summary> Singleton </summary>
		private static Importer ptImporter = null;
		private static object singletoneLock = new object();

		private ConcreteModel concreteModel;
		private Delta delta;
		private ImportHelper importHelper;
		private TransformAndLoadReport report;


		#region Properties
		public static Importer Instance
		{
			get
			{
				if (ptImporter == null)
				{
					lock (singletoneLock)
					{
						if (ptImporter == null)
						{
							ptImporter = new Importer();
							ptImporter.Reset();
						}
					}
				}
				return ptImporter;
			}
		}

		public Delta NMSDelta
		{
			get 
			{
				return delta;
			}
		}
		#endregion Properties


		public void Reset()
		{
			concreteModel = null;
			delta = new Delta();
			importHelper = new ImportHelper();
			report = null;
		}

		public TransformAndLoadReport CreateNMSDelta(ConcreteModel cimConcreteModel)
		{
			LogManager.Log("Importing CIM22 Elements...", LogLevel.Info);
			report = new TransformAndLoadReport();
			concreteModel = cimConcreteModel;
			delta.ClearDeltaOperations();

			if ((concreteModel != null) && (concreteModel.ModelMap != null))
			{
				try
				{
					// convert into DMS elements
					ConvertModelAndPopulateDelta();
				}
				catch (Exception ex)
				{
					string message = string.Format("{0} - ERROR in data import - {1}", DateTime.Now, ex.Message);
					LogManager.Log(message);
					report.Report.AppendLine(ex.Message);
					report.Success = false;
				}
			}
			LogManager.Log("Importing CIM22 Elements - END.", LogLevel.Info);
			return report;
		}

		/// <summary>
		/// Method performs conversion of network elements from CIM based concrete model into DMS model.
		/// </summary>
		private void ConvertModelAndPopulateDelta()
		{
			LogManager.Log("Loading elements and creating delta...", LogLevel.Info);

            //// import all concrete model types (DMSType enum)
            //typeIdsInInsertOrder.Add(ModelCode.SEASON);
            //typeIdsInInsertOrder.Add(ModelCode.DAYTYPE);
            //typeIdsInInsertOrder.Add(ModelCode.TAPCHANGER);
            //typeIdsInInsertOrder.Add(ModelCode.TERMINAL);
            //typeIdsInInsertOrder.Add(ModelCode.REGULATINGCONTROL);
            //typeIdsInInsertOrder.Add(ModelCode.CONDUCTINGEQUIPMENT);
            //typeIdsInInsertOrder.Add(ModelCode.TAPSCHEDULE);
            //typeIdsInInsertOrder.Add(ModelCode.REGULATIONSCHEDULE);

            ImportSeasons();
            ImportDayTypes();
            ImportTapChangers();
            ImportConductingEquipments();
            ImportTerminals();
            ImportRegulatingControls();
            ImportTapSchedules();
            ImportRegulationSchedules();

            LogManager.Log("Loading elements and creating delta completed.", LogLevel.Info);
		}

        private void ImportRegulationSchedules()
        {
            SortedDictionary<string, object> cim = concreteModel.GetAllObjectsOfType("FTN.RegulationSchedule");
            if (cim != null)
            {
                foreach (KeyValuePair<string, object> pair in cim)
                {
                    FTN.RegulationSchedule co = pair.Value as FTN.RegulationSchedule;

                    ResourceDescription rd = CreateRegulationScheduleResourceDescription(co);
                    if (rd != null)
                    {
                        delta.AddDeltaOperation(DeltaOpType.Insert, rd, true);
                        report.Report.Append("RegulationSchedule ID = ").Append(co.ID).Append(" SUCCESSFULLY converted to GID = ").AppendLine(rd.Id.ToString());
                    }
                    else
                    {
                        report.Report.Append("RegulationSchedule ID = ").Append(co.ID).AppendLine(" FAILED to be converted");
                    }
                }
                report.Report.AppendLine();
            }
        }

        private ResourceDescription CreateRegulationScheduleResourceDescription(FTN.RegulationSchedule co)
        {
            ResourceDescription rd = null;
            if (co != null)
            {
                long gid = ModelCodeHelper.CreateGlobalId(0, (short)DMSType.REGULATIONSCHEDULE, importHelper.CheckOutIndexForDMSType(DMSType.REGULATIONSCHEDULE));
                rd = new ResourceDescription(gid);
                importHelper.DefineIDMapping(co.ID, gid);

                Converter.PopulateRegulationScheduleProperties(co, rd, importHelper, report);
            }
            return rd;
        }

        private void ImportTapSchedules()
        {
            SortedDictionary<string, object> cim = concreteModel.GetAllObjectsOfType("FTN.TapSchedule");
            if (cim != null)
            {
                foreach (KeyValuePair<string, object> pair in cim)
                {
                    FTN.TapSchedule co = pair.Value as FTN.TapSchedule;

                    ResourceDescription rd = CreateTapScheduleResourceDescription(co);
                    if (rd != null)
                    {
                        delta.AddDeltaOperation(DeltaOpType.Insert, rd, true);
                        report.Report.Append("TapSchedule ID = ").Append(co.ID).Append(" SUCCESSFULLY converted to GID = ").AppendLine(rd.Id.ToString());
                    }
                    else
                    {
                        report.Report.Append("TapSchedule ID = ").Append(co.ID).AppendLine(" FAILED to be converted");
                    }
                }
                report.Report.AppendLine();
            }
        }

        private ResourceDescription CreateTapScheduleResourceDescription(FTN.TapSchedule co)
        {
            ResourceDescription rd = null;
            if (co != null)
            {
                long gid = ModelCodeHelper.CreateGlobalId(0, (short)DMSType.TAPSCHEDULE, importHelper.CheckOutIndexForDMSType(DMSType.TAPSCHEDULE));
                rd = new ResourceDescription(gid);
                importHelper.DefineIDMapping(co.ID, gid);

                Converter.PopulateTapScheduleProperties(co, rd, importHelper, report);
            }
            return rd;
        }

        private void ImportConductingEquipments()
        {
            SortedDictionary<string, object> cim = concreteModel.GetAllObjectsOfType("FTN.ConductingEquipment");
            if (cim != null)
            {
                foreach (KeyValuePair<string, object> pair in cim)
                {
                    FTN.ConductingEquipment co = pair.Value as FTN.ConductingEquipment;

                    ResourceDescription rd = CreateConductingEquipmentResourceDescription(co);
                    if (rd != null)
                    {
                        delta.AddDeltaOperation(DeltaOpType.Insert, rd, true);
                        report.Report.Append("ConductingEquipment ID = ").Append(co.ID).Append(" SUCCESSFULLY converted to GID = ").AppendLine(rd.Id.ToString());
                    }
                    else
                    {
                        report.Report.Append("ConductingEquipment ID = ").Append(co.ID).AppendLine(" FAILED to be converted");
                    }
                }
                report.Report.AppendLine();
            }
        }

        private ResourceDescription CreateConductingEquipmentResourceDescription(FTN.ConductingEquipment co)
        {
            ResourceDescription rd = null;
            if (co != null)
            {
                long gid = ModelCodeHelper.CreateGlobalId(0, (short)DMSType.CONDUCTINGEQUIPMENT, importHelper.CheckOutIndexForDMSType(DMSType.CONDUCTINGEQUIPMENT));
                rd = new ResourceDescription(gid);
                importHelper.DefineIDMapping(co.ID, gid);

                Converter.PopulateConductingEquipmentProperties(co, rd);
            }
            return rd;
        }

        private void ImportRegulatingControls()
        {
            SortedDictionary<string, object> cim = concreteModel.GetAllObjectsOfType("FTN.RegulatingControl");
            if (cim != null)
            {
                foreach (KeyValuePair<string, object> pair in cim)
                {
                    FTN.RegulatingControl co = pair.Value as FTN.RegulatingControl;

                    ResourceDescription rd = CreateRegulatingControlResourceDescription(co);
                    if (rd != null)
                    {
                        delta.AddDeltaOperation(DeltaOpType.Insert, rd, true);
                        report.Report.Append("RegulatingControl ID = ").Append(co.ID).Append(" SUCCESSFULLY converted to GID = ").AppendLine(rd.Id.ToString());
                    }
                    else
                    {
                        report.Report.Append("RegulataingControl ID = ").Append(co.ID).AppendLine(" FAILED to be converted");
                    }
                }
                report.Report.AppendLine();
            }
        }

        private ResourceDescription CreateRegulatingControlResourceDescription(FTN.RegulatingControl co)
        {
            ResourceDescription rd = null;
            if (co != null)
            {
                long gid = ModelCodeHelper.CreateGlobalId(0, (short)DMSType.REGULATINGCONTROL, importHelper.CheckOutIndexForDMSType(DMSType.REGULATINGCONTROL));
                rd = new ResourceDescription(gid);
                importHelper.DefineIDMapping(co.ID, gid);

                Converter.PopulateRegulatingControlProperties(co, rd, importHelper, report);
            }
            return rd;
        }

        private void ImportTerminals()
        {
            SortedDictionary<string, object> cim = concreteModel.GetAllObjectsOfType("FTN.Terminal");
            if (cim != null)
            {
                foreach (KeyValuePair<string, object> pair in cim)
                {
                    FTN.Terminal co = pair.Value as FTN.Terminal;

                    ResourceDescription rd = CreateTerminalResourceDescription(co);
                    if (rd != null)
                    {
                        delta.AddDeltaOperation(DeltaOpType.Insert, rd, true);
                        report.Report.Append("Terminal ID = ").Append(co.ID).Append(" SUCCESSFULLY converted to GID = ").AppendLine(rd.Id.ToString());
                    }
                    else
                    {
                        report.Report.Append("Terminal ID = ").Append(co.ID).AppendLine(" FAILED to be converted");
                    }
                }
                report.Report.AppendLine();
            }
        }

        private ResourceDescription CreateTerminalResourceDescription(FTN.Terminal co)
        {
            ResourceDescription rd = null;
            if (co != null)
            {
                long gid = ModelCodeHelper.CreateGlobalId(0, (short)DMSType.TERMINAL, importHelper.CheckOutIndexForDMSType(DMSType.TERMINAL));
                rd = new ResourceDescription(gid);
                importHelper.DefineIDMapping(co.ID, gid);

                Converter.PopulateTerminalProperties(co, rd, importHelper, report);
            }
            return rd;
        }

        private void ImportTapChangers()
        {
            SortedDictionary<string, object> cim = concreteModel.GetAllObjectsOfType("FTN.TapChanger");
            if (cim != null)
            {
                foreach (KeyValuePair<string, object> pair in cim)
                {
                    FTN.TapChanger co = pair.Value as FTN.TapChanger;

                    ResourceDescription rd = CreateTapChangerResourceDescription(co);
                    if (rd != null)
                    {
                        delta.AddDeltaOperation(DeltaOpType.Insert, rd, true);
                        report.Report.Append("TapChanger ID = ").Append(co.ID).Append(" SUCCESSFULLY converted to GID = ").AppendLine(rd.Id.ToString());
                    }
                    else
                    {
                        report.Report.Append("TapChanger ID = ").Append(co.ID).AppendLine(" FAILED to be converted");
                    }
                }
                report.Report.AppendLine();
            }
        }

        private ResourceDescription CreateTapChangerResourceDescription(FTN.TapChanger co)
        {
            ResourceDescription rd = null;
            if (co != null)
            {
                long gid = ModelCodeHelper.CreateGlobalId(0, (short)DMSType.TAPCHANGER, importHelper.CheckOutIndexForDMSType(DMSType.TAPCHANGER));
                rd = new ResourceDescription(gid);
                importHelper.DefineIDMapping(co.ID, gid);

                Converter.PopulateTapChangerProperties(co, rd);
            }
            return rd;
        }

        private void ImportDayTypes()
        {
            SortedDictionary<string, object> cim = concreteModel.GetAllObjectsOfType("FTN.DayType");
            if (cim != null)
            {
                foreach (KeyValuePair<string, object> pair in cim)
                {
                    FTN.DayType co = pair.Value as FTN.DayType;

                    ResourceDescription rd = CreateDayTypeResourceDescription(co);
                    if (rd != null)
                    {
                        delta.AddDeltaOperation(DeltaOpType.Insert, rd, true);
                        report.Report.Append("DayType ID = ").Append(co.ID).Append(" SUCCESSFULLY converted to GID = ").AppendLine(rd.Id.ToString());
                    }
                    else
                    {
                        report.Report.Append("DayType ID = ").Append(co.ID).AppendLine(" FAILED to be converted");
                    }
                }
                report.Report.AppendLine();
            }
        }

        private ResourceDescription CreateDayTypeResourceDescription(FTN.DayType co)
        {
            ResourceDescription rd = null;
            if (co != null)
            {
                long gid = ModelCodeHelper.CreateGlobalId(0, (short)DMSType.DAYTYPE, importHelper.CheckOutIndexForDMSType(DMSType.DAYTYPE));
                rd = new ResourceDescription(gid);
                importHelper.DefineIDMapping(co.ID, gid);

                Converter.PopulateDayTypeProperties(co, rd);
            }
            return rd;
        }

        private void ImportSeasons()
        {
            SortedDictionary<string, object> cim = concreteModel.GetAllObjectsOfType("FTN.Season");
            if (cim != null)
            {
                foreach (KeyValuePair<string, object> pair in cim)
                {
                    FTN.Season co = pair.Value as FTN.Season;

                    ResourceDescription rd = CreateSeasonResourceDescription(co);
                    if (rd != null)
                    {
                        delta.AddDeltaOperation(DeltaOpType.Insert, rd, true);
                        report.Report.Append("Season ID = ").Append(co.ID).Append(" SUCCESSFULLY converted to GID = ").AppendLine(rd.Id.ToString());
                    }
                    else
                    {
                        report.Report.Append("Season ID = ").Append(co.ID).AppendLine(" FAILED to be converted");
                    }
                }
                report.Report.AppendLine();
            }
        }

        private ResourceDescription CreateSeasonResourceDescription(FTN.Season co)
        {
            ResourceDescription rd = null;
            if (co != null)
            {
                long gid = ModelCodeHelper.CreateGlobalId(0, (short)DMSType.SEASON, importHelper.CheckOutIndexForDMSType(DMSType.SEASON));
                rd = new ResourceDescription(gid);
                importHelper.DefineIDMapping(co.ID, gid);

                Converter.PopulateSeasonProperties(co, rd);
            }
            return rd;
        }
    }
}

